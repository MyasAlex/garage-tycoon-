"""models/car.py - ОБНОВЛЁННАЯ модель машины"""

import random

class Car:
    """Автомобиль с расширенным тюнингом"""
    
    def __init__(self, name, hp, weight, price, condition=1.0):
        self.name = name
        self.base_hp = hp
        self.base_weight = weight
        self.price = price
        self.condition = max(0.1, min(1.0, condition))
        
        # Передачи (можно будет настраивать)
        self.gear_ratios = [3.5, 2.5, 1.8, 1.3, 1.0, 0.8]  # 6 передач
        self.final_drive = 3.9
        
        # РАСШИРЕННЫЕ СЛОТЫ для деталей
        self.parts = {
            'engine': None,
            'turbo': None,
            'tires': None,
            'transmission': None,
            'suspension': None,  # НОВОЕ
            'exhaust': None,     # НОВОЕ
            'nos': None          # НОВОЕ
        }
        
        # Цвет для визуализации
        self.color = (
            random.randint(50, 255),
            random.randint(50, 255),
            random.randint(50, 255)
        )
        
        # Статистика использования
        self.miles_driven = 0
        self.races_won = 0
        self.races_lost = 0
        self.total_earnings = 0
    
    @classmethod
    def from_dict(cls, data):
        """Создать из JSON"""
        return cls(
            name=data.get('name', 'Машина'),
            hp=data.get('hp', 100),
            weight=data.get('weight', 1200),
            price=data.get('price', 1000),
            condition=data.get('condition', 1.0)
        )
    
    def install_part(self, part):
        """Установить деталь"""
        if part.part_type in self.parts:
            # Снять старую деталь если есть
            old_part = self.parts[part.part_type]
            
            # Установить новую
            self.parts[part.part_type] = part
            return True, old_part
        return False, None
    
    def remove_part(self, part_type):
        """Снять деталь"""
        if part_type in self.parts and self.parts[part_type]:
            removed = self.parts[part_type]
            self.parts[part_type] = None
            return removed
        return None
    
    def get_total_hp(self):
        """Общая мощность"""
        total = self.base_hp
        
        for part in self.parts.values():
            if part:
                total += part.get_effective_hp()
        
        return total * self.condition
    
    def get_total_weight(self):
        """Общий вес"""
        total = self.base_weight
        
        for part in self.parts.values():
            if part:
                total += part.weight_bonus
        
        return max(500, total)  # Минимум 500кг
    
    def get_power_to_weight(self):
        """Мощность на тонну"""
        return self.get_total_hp() / (self.get_total_weight() / 1000)
    
    def get_grip(self):
        """Сцепление (от покрышек)"""
        if self.parts['tires']:
            return self.parts['tires'].grip
        return 0.7
    
    def get_shift_speed(self):
        """Скорость переключения"""
        if self.parts['transmission']:
            return self.parts['transmission'].shift_speed
        return 1.0
    
    def get_handling(self):
        """Управляемость (от подвески)"""
        if self.parts['suspension']:
            return self.parts['suspension'].handling
        return 0.7
    
    def get_nos_boost(self):
        """Бонус от закиси азота"""
        if self.parts['nos']:
            return self.parts['nos'].nos_boost
        return 0
    
    def calculate_performance(self):
        """Время разгона 0-100 км/ч"""
        pwr = self.get_power_to_weight()
        grip_factor = self.get_grip()
        
        # Базовое время
        base_time = 15.0 / (pwr / 100)
        
        # Корректировка на сцепление
        time = base_time / grip_factor
        
        return round(max(2.0, time), 2)
    
    def calculate_quarter_mile_time(self):
        """Время четверть мили (для драг-рейсинга)"""
        pwr = self.get_power_to_weight()
        grip = self.get_grip()
        shift = self.get_shift_speed()
        
        # Формула: базовое время зависит от мощности и сцепления
        base = 20.0 - (pwr / 50)
        time = base / (grip * shift)
        
        return round(max(8.0, time), 2)
    
    def get_value(self):
        """Текущая стоимость"""
        base_value = self.price * self.condition
        parts_value = sum(p.get_sell_price() for p in self.parts.values() if p)
        return int(base_value + parts_value)
    
    def get_repair_cost(self):
        """Стоимость полного ремонта"""
        # Ремонт кузова
        body_repair = int(self.price * 0.1 * (1 - self.condition))
        
        # Ремонт деталей
        parts_repair = sum(p.repair(0.1) for p in self.parts.values() if p and p.condition < 1.0)
        
        return body_repair + parts_repair
    
    def repair(self):
        """Починить машину и детали"""
        cost = self.get_repair_cost()
        self.condition = 1.0
        
        for part in self.parts.values():
            if part:
                part.condition = 1.0
                part.durability = 100
        
        return cost
    
    def wear_parts(self, race_intensity=0.01):
        """Износ деталей после гонки"""
        self.condition = max(0.5, self.condition - race_intensity * 0.5)
        
        for part in self.parts.values():
            if part:
                part.wear(race_intensity)
    
    def __str__(self):
        return f"{self.name} | {int(self.get_total_hp())}HP | {int(self.get_total_weight())}kg | {self.calculate_performance()}s"
    
    def get_stats_dict(self):
        """Словарь со всеми характеристиками"""
        return {
            'hp': int(self.get_total_hp()),
            'weight': int(self.get_total_weight()),
            'power_to_weight': round(self.get_power_to_weight(), 2),
            '0-100': self.calculate_performance(),
            'quarter_mile': self.calculate_quarter_mile_time(),
            'grip': self.get_grip(),
            'shift_speed': self.get_shift_speed(),
            'handling': self.get_handling(),
            'condition': int(self.condition * 100),
            'value': self.get_value()
        }
