"""models/player.py - ОБНОВЛЁННЫЙ игрок с прогрессией"""

from config.game_config import STARTING_MONEY, MAX_GARAGE_SIZE

class Player:
    """Игрок с уровнем, гаражом и инвентарём"""
    
    def __init__(self):
        # Финансы
        self.money = STARTING_MONEY
        
        # Гараж
        self.garage = []
        self.selected_car_index = 0
        
        # НОВОЕ: Инвентарь деталей
        self.inventory = []  # Купленные, но не установленные детали
        
        # НОВОЕ: Прогрессия
        self.level = 1
        self.xp = 0
        self.xp_to_next_level = 100
        
        # НОВОЕ: Репутация
        self.reputation = 0
        
        # НОВОЕ: Статистика
        self.stats = {
            'total_races': 0,
            'races_won': 0,
            'races_lost': 0,
            'total_earnings': 0,
            'total_spent': 0,
            'cars_bought': 0,
            'cars_sold': 0,
            'parts_bought': 0,
            'parts_sold': 0,
            'miles_driven': 0
        }
    
    # ==================== ДЕНЬГИ ====================
    
    def add_money(self, amount):
        """Добавить деньги"""
        self.money += amount
        self.stats['total_earnings'] += amount
    
    def spend_money(self, amount):
        """Потратить деньги (возвращает True если успешно)"""
        if self.money >= amount:
            self.money -= amount
            self.stats['total_spent'] += amount
            return True
        return False
    
    # ==================== ГАРАЖ ====================
    
    def buy_car(self, car):
        """Купить машину"""
        if self.spend_money(car.price) and len(self.garage) < MAX_GARAGE_SIZE:
            self.garage.append(car)
            self.stats['cars_bought'] += 1
            self.add_xp(50)  # XP за покупку
            return True
        return False
    
    def sell_car(self, car):
        """Продать машину"""
        if car in self.garage:
            value = car.get_value()
            self.add_money(value)
            
            # Снять все детали в инвентарь
            for part in car.parts.values():
                if part:
                    self.inventory.append(part)
            
            self.garage.remove(car)
            self.stats['cars_sold'] += 1
            
            if self.selected_car_index >= len(self.garage) and self.garage:
                self.selected_car_index = len(self.garage) - 1
            
            return True
        return False
    
    def get_selected_car(self):
        """Получить выбранную машину"""
        if self.garage:
            return self.garage[self.selected_car_index]
        return None
    
    def select_next_car(self):
        """След машина"""
        if self.garage:
            self.selected_car_index = (self.selected_car_index + 1) % len(self.garage)
    
    def select_previous_car(self):
        """Пред машина"""
        if self.garage:
            self.selected_car_index = (self.selected_car_index - 1) % len(self.garage)
    
    # ==================== ИНВЕНТАРЬ ====================
    
    def buy_part(self, part):
        """Купить деталь в инвентарь"""
        if self.spend_money(part.price):
            self.inventory.append(part)
            self.stats['parts_bought'] += 1
            self.add_xp(10)
            return True
        return False
    
    def sell_part(self, part):
        """Продать деталь из инвентаря"""
        if part in self.inventory:
            value = part.get_sell_price()
            self.add_money(value)
            self.inventory.remove(part)
            self.stats['parts_sold'] += 1
            return True
        return False
    
    def install_part_from_inventory(self, car, part):
        """Установить деталь из инвентаря на машину"""
        if part in self.inventory and car in self.garage:
            success, old_part = car.install_part(part)
            
            if success:
                self.inventory.remove(part)
                
                # Старую деталь в инвентарь
                if old_part:
                    self.inventory.append(old_part)
                
                return True
        return False
    
    def remove_part_to_inventory(self, car, part_type):
        """Снять деталь с машины в инвентарь"""
        if car in self.garage:
            removed = car.remove_part(part_type)
            if removed:
                self.inventory.append(removed)
                return True
        return False
    
    # ==================== ПРОГРЕССИЯ ====================
    
    def add_xp(self, amount):
        """Добавить опыт"""
        self.xp += amount
        
        # Проверка повышения уровня
        while self.xp >= self.xp_to_next_level:
            self.level_up()
    
    def level_up(self):
        """Повысить уровень"""
        self.xp -= self.xp_to_next_level
        self.level += 1
        self.xp_to_next_level = int(self.xp_to_next_level * 1.5)
        
        # Награда за уровень
        reward = 500 * self.level
        self.add_money(reward)
        
        print(f"🎉 LEVEL UP! Уровень {self.level}!")
        print(f"💰 Награда: ${reward}")
    
    def add_reputation(self, amount):
        """Добавить репутацию"""
        self.reputation += amount
    
    # ==================== ГОНКИ ====================
    
    def win_race(self, prize_money, xp_reward=50):
        """Победа в гонке"""
        self.add_money(prize_money)
        self.add_xp(xp_reward)
        self.add_reputation(10)
        self.stats['races_won'] += 1
        self.stats['total_races'] += 1
    
    def lose_race(self, xp_reward=10):
        """Поражение в гонке"""
        self.add_xp(xp_reward)
        self.add_reputation(2)
        self.stats['races_lost'] += 1
        self.stats['total_races'] += 1
    
    # ==================== РЕМОНТ ====================
    
    def repair_car(self, car):
        """Починить машину"""
        if car in self.garage:
            cost = car.get_repair_cost()
            if self.spend_money(cost):
                car.repair()
                return True, cost
        return False, 0
    
    def repair_all_cars(self):
        """Починить все машины"""
        total_cost = 0
        for car in self.garage:
            cost = car.get_repair_cost()
            total_cost += cost
        
        if self.spend_money(total_cost):
            for car in self.garage:
                car.repair()
            return True, total_cost
        return False, 0
    
    # ==================== СТАТИСТИКА ====================
    
    def get_win_rate(self):
        """Процент побед"""
        if self.stats['total_races'] == 0:
            return 0
        return round(self.stats['races_won'] / self.stats['total_races'] * 100, 1)
    
    def get_net_worth(self):
        """Общая стоимость (деньги + машины + детали)"""
        cars_value = sum(car.get_value() for car in self.garage)
        parts_value = sum(part.get_sell_price() for part in self.inventory)
        return self.money + cars_value + parts_value
    
    def __str__(self):
        return f"Player Lv.{self.level} | ${self.money} | {len(self.garage)} cars | Rep: {self.reputation}"
