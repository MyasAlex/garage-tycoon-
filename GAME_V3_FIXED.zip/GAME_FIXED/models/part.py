"""models/part.py - ОБНОВЛЁННАЯ модель детали"""

class Part:
    """Деталь для тюнинга машины"""
    
    def __init__(self, 
                 part_id,
                 name, 
                 part_type, 
                 hp_bonus, 
                 weight_bonus, 
                 price,
                 level_required=0,
                 description="",
                 **kwargs):
        """
        Args:
            part_id: Уникальный ID
            name: Название
            part_type: Тип (engine, turbo, tires, transmission, suspension, exhaust, nos)
            hp_bonus: Бонус к мощности
            weight_bonus: Изменение веса (может быть отрицательным)
            price: Цена
            level_required: Требуемый уровень игрока
            description: Описание
            **kwargs: Дополнительные параметры (grip, shift_speed, handling, nos_boost)
        """
        self.part_id = part_id
        self.name = name
        self.part_type = part_type
        self.hp_bonus = hp_bonus
        self.weight_bonus = weight_bonus
        self.price = price
        self.level_required = level_required
        self.description = description
        
        # Дополнительные параметры
        self.grip = kwargs.get('grip', 0.7)  # Для покрышек
        self.shift_speed = kwargs.get('shift_speed', 1.0)  # Для трансмиссии
        self.handling = kwargs.get('handling', 0.7)  # Для подвески
        self.nos_boost = kwargs.get('nos_boost', 0)  # Для NOS
        
        # Состояние (изнашивается)
        self.condition = 1.0
        self.durability = 100  # Прочность
    
    @classmethod
    def from_dict(cls, data):
        """Создать деталь из словаря (JSON)"""
        return cls(
            part_id=data.get('id', 'unknown'),
            name=data.get('name', 'Unknown Part'),
            part_type=data.get('type', 'engine'),
            hp_bonus=data.get('hp_bonus', 0),
            weight_bonus=data.get('weight_bonus', 0),
            price=data.get('price', 0),
            level_required=data.get('level_required', 0),
            description=data.get('description', ''),
            grip=data.get('grip', 0.7),
            shift_speed=data.get('shift_speed', 1.0),
            handling=data.get('handling', 0.7),
            nos_boost=data.get('nos_boost', 0)
        )
    
    def get_sell_price(self):
        """Цена продажи (50% от исходной * состояние)"""
        return int(self.price * 0.5 * self.condition)
    
    def wear(self, amount=0.01):
        """Износ детали"""
        self.condition = max(0.1, self.condition - amount)
        self.durability = max(0, self.durability - amount * 100)
    
    def repair(self, cost_multiplier=0.1):
        """Ремонт детали"""
        repair_cost = int(self.price * cost_multiplier * (1 - self.condition))
        self.condition = 1.0
        self.durability = 100
        return repair_cost
    
    def get_effective_hp(self):
        """HP с учётом состояния"""
        return int(self.hp_bonus * self.condition)
    
    def __str__(self):
        return f"{self.name} (+{self.hp_bonus}HP, {self.weight_bonus:+}kg) ${self.price}"
    
    def __repr__(self):
        return f"Part('{self.name}', {self.part_type}, {self.hp_bonus}HP)"
