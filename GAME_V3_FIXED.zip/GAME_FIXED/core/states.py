"""core/states.py - Состояния игры"""

from enum import Enum, auto

class GameState(Enum):
    """Перечисление игровых состояний"""
    MENU = auto()
    GARAGE = auto()
    MARKET = auto()
    TUNING = auto()
    RACE = auto()
    QUIT = auto()

# Для удобства
MENU = GameState.MENU
GARAGE = GameState.GARAGE
MARKET = GameState.MARKET
TUNING = GameState.TUNING
RACE = GameState.RACE
QUIT = GameState.QUIT
