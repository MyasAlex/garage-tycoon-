"""core/game.py - ОБНОВЛЁННОЕ ядро с Tuning"""

import pygame
import sys
from config.settings import *
from core.states import *
from models.player import Player
from scenes.menu_scene import MenuScene
from scenes.garage_scene import GarageScene
from scenes.market_scene import MarketScene
from scenes.tuning_scene import TuningScene
from scenes.race_scene import RaceScene

class Game:
    """Главный класс игры v2.0"""
    
    def __init__(self):
        pygame.init()
        
        self.screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
        pygame.display.set_caption(WINDOW_TITLE)
        
        self.clock = pygame.time.Clock()
        
        self.font_small = pygame.font.Font(None, FONT_SMALL)
        self.font_medium = pygame.font.Font(None, FONT_MEDIUM)
        self.font_large = pygame.font.Font(None, FONT_LARGE)
        
        self.current_state = MENU
        self.running = True
        
        self.player = Player()
        
        self.scenes = {
            MENU: MenuScene(self),
            GARAGE: GarageScene(self),
            MARKET: MarketScene(self),
            TUNING: TuningScene(self),  # НОВОЕ!
            RACE: RaceScene(self)  # НОВОЕ!
        }
        
        print("✅ Game v2.0 инициализирована!")
        print(f"📺 {SCREEN_WIDTH}x{SCREEN_HEIGHT}")
        print(f"💰 ${self.player.money}")
        print(f"⭐ Level {self.player.level}")
    
    def handle_events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.running = False
            
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    # ESC возвращает в предыдущее меню
                    if self.current_state == TUNING:
                        self.current_state = GARAGE
                    elif self.current_state == RACE:
                        self.current_state = GARAGE
                    elif self.current_state in [GARAGE, MARKET]:
                        self.current_state = MENU
                    else:
                        self.running = False
            
            if self.current_state in self.scenes:
                self.scenes[self.current_state].handle_event(event)
    
    def update(self, dt):
        if self.current_state in self.scenes:
            self.scenes[self.current_state].update(dt)
    
    def draw(self):
        self.screen.fill(BLACK)
        
        if self.current_state in self.scenes:
            self.scenes[self.current_state].draw(self.screen)
        else:
            text = self.game.font_large.render(f"{self.current_state.name}", True, WHITE)
            self.screen.blit(text, (400, 350))
        
        # HUD
        if SHOW_FPS:
            fps = self.font_small.render(f"FPS: {int(self.clock.get_fps())}", True, WHITE)
            self.screen.blit(fps, (10, 10))
        
        # Деньги и уровень
        money = self.font_small.render(f"${self.player.money}", True, GREEN)
        self.screen.blit(money, (10, 40))
        
        level = self.font_small.render(f"Lv.{self.player.level}", True, CYAN)
        self.screen.blit(level, (10, 65))
        
        # XP бар
        xp_bar_width = 150
        xp_bar_height = 10
        xp_progress = self.player.xp / self.player.xp_to_next_level
        
        pygame.draw.rect(self.screen, DARK_GRAY, (10, 90, xp_bar_width, xp_bar_height))
        pygame.draw.rect(self.screen, YELLOW, (10, 90, int(xp_bar_width * xp_progress), xp_bar_height))
        pygame.draw.rect(self.screen, WHITE, (10, 90, xp_bar_width, xp_bar_height), 1)
        
        pygame.display.flip()
    
    def run(self):
        print("🎮 Запущено!")
        
        while self.running:
            dt = self.clock.tick(FPS) / 1000.0
            
            self.handle_events()
            self.update(dt)
            self.draw()
        
        self.quit()
    
    def quit(self):
        print("\n" + "=" * 50)
        print("📊 ИТОГОВАЯ СТАТИСТИКА:")
        print("=" * 50)
        print(f"💰 Деньги: ${self.player.money}")
        print(f"⭐ Уровень: {self.player.level}")
        print(f"🚗 Машин: {len(self.player.garage)}")
        print(f"🔧 Деталей: {len(self.player.inventory)}")
        print(f"🏁 Гонок: {self.player.stats['total_races']}")
        print(f"🏆 Побед: {self.player.stats['races_won']}")
        print(f"💸 Заработано: ${self.player.stats['total_earnings']}")
        print("=" * 50)
        print("👋 Выход...")
        
        pygame.quit()
        sys.exit()
