"""config/game_config.py - Игровой баланс"""

# Игрок
STARTING_MONEY = 5000
MAX_GARAGE_SIZE = 10

# Рынок
MARKET_REFRESH_COST = 100
MIN_MARKET_CARS = 3
MAX_MARKET_CARS = 6
