"""config/settings.py - Настройки игры"""

# Окно
SCREEN_WIDTH = 1200
SCREEN_HEIGHT = 800
FPS = 60
WINDOW_TITLE = "Zero to Hero: Garage Tycoon"

# Цвета (RGB)
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
GRAY = (100, 100, 100)
DARK_GRAY = (50, 50, 50)
RED = (255, 50, 50)
GREEN = (50, 255, 50)
BLUE = (50, 50, 255)
YELLOW = (255, 255, 0)
ORANGE = (255, 165, 0)
PURPLE = (200, 50, 200)
CYAN = (0, 255, 255)

# Шрифты
FONT_SMALL = 24
FONT_MEDIUM = 32
FONT_LARGE = 48

# Отладка
SHOW_FPS = True
