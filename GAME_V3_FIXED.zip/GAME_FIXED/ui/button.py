"""ui/button.py - Кнопка"""

import pygame
from config.settings import WHITE, BLACK

class Button:
    """Кликабельная кнопка"""
    
    def __init__(self, x, y, width, height, text, color, font):
        self.rect = pygame.Rect(x, y, width, height)
        self.text = text
        self.color = color
        self.font = font
        self.hovered = False
    
    def handle_event(self, event):
        """Обработка клика"""
        if event.type == pygame.MOUSEMOTION:
            self.hovered = self.rect.collidepoint(event.pos)
        
        if event.type == pygame.MOUSEBUTTONDOWN:
            if self.rect.collidepoint(event.pos):
                return True
        return False
    
    def draw(self, screen):
        """Отрисовка"""
        # Светлее если наведён курсор
        color = tuple(min(c + 30, 255) for c in self.color) if self.hovered else self.color
        
        pygame.draw.rect(screen, color, self.rect, border_radius=5)
        pygame.draw.rect(screen, WHITE, self.rect, 3, border_radius=5)
        
        text_surface = self.font.render(self.text, True, WHITE)
        text_rect = text_surface.get_rect(center=self.rect.center)
        screen.blit(text_surface, text_rect)
