"""main.py - Запуск Garage Tycoon v2.0"""

from core.game import Game
from models.car import Car
import json

def main():
    print("=" * 60)
    print("🏎️  GARAGE TYCOON v2.0")
    print("=" * 60)
    print("Новое: Тюнинг система, прогрессия, детальная экономика")
    print("=" * 60)
    print()
    
    game = Game()
    
    # Добавляем стартовые машины
    print("🎁 Стартовые машины...")
    
    try:
        with open("data/cars.json", 'r', encoding='utf-8') as f:
            data = json.load(f)
            cars = data.get('cars', [])[:2]  # Первые 2 машины
            
            for car_data in cars:
                car = Car.from_dict(car_data)
                game.player.garage.append(car)
                print(f"  ✅ {car.name}")
    except:
        print("  ⚠️  cars.json не найден, создаём тестовые")
        car1 = Car("Машина #1", 125, 1050, 800)
        car2 = Car("Машина #2", 130, 970, 1000)
        game.player.garage.extend([car1, car2])
    
    print()
    print(f"💰 Деньги: ${game.player.money}")
    print(f"⭐ Уровень: {game.player.level}")
    print(f"🚗 Машин: {len(game.player.garage)}")
    print()
    print("🎮 Управление:")
    print("  • MOUSE - Клики")
    print("  • ← → - Навигация (в гараже)")
    print("  • ESC - Назад")
    print()
    print("=" * 60)
    print()
    
    game.run()

if __name__ == "__main__":
    main()
