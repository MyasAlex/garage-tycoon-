"""scenes/garage_scene.py - Гараж (цветные блоки)"""

import pygame
from config.settings import *
from core.states import MENU, TUNING, RACE
from ui.button import Button

class GarageScene:
    """Гараж с цветными машинами"""
    
    def __init__(self, game):
        self.game = game
        
        button_y = SCREEN_HEIGHT - 100
        self.buttons = [
            Button(50, button_y, 150, 50, "BACK", GRAY, game.font_medium),
            Button(220, button_y, 150, 50, "TUNING", ORANGE, game.font_medium),
            Button(390, button_y, 150, 50, "RACE", GREEN, game.font_medium),
            Button(560, button_y, 150, 50, "SELL", RED, game.font_medium),
        ]
    
    def handle_event(self, event):
        for i, button in enumerate(self.buttons):
            if button.handle_event(event):
                if i == 0:
                    self.game.current_state = MENU
                elif i == 1:
                    if self.game.player.garage:
                        self.game.current_state = TUNING
                elif i == 2:
                    if self.game.player.garage:
                        self.game.current_state = RACE
                elif i == 3:
                    self.sell_car()
        
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_LEFT:
                self.game.player.select_previous_car()
            elif event.key == pygame.K_RIGHT:
                self.game.player.select_next_car()
    
    def sell_car(self):
        car = self.game.player.get_selected_car()
        if car:
            value = car.get_value()
            self.game.player.sell_car(car)
            print(f"💰 Продано за ${value}")
    
    def update(self, dt):
        pass
    
    def draw(self, screen):
        title = self.game.font_large.render("GARAGE", True, YELLOW)
        screen.blit(title, (50, 30))
        
        if not self.game.player.garage:
            text = self.game.font_medium.render("Нет машин!", True, WHITE)
            screen.blit(text, (SCREEN_WIDTH // 2 - 100, SCREEN_HEIGHT // 2))
        else:
            car = self.game.player.get_selected_car()
            
            # Машина - ЦВЕТНОЙ БЛОК
            car_x = SCREEN_WIDTH // 2 - 150
            car_y = 200
            car_w = 300
            car_h = 95
            
            # Фон
            pygame.draw.rect(screen, DARK_GRAY, (car_x - 10, car_y - 10, car_w + 20, car_h + 20))
            
            # Кузов
            pygame.draw.rect(screen, car.color, (car_x, car_y, car_w, car_h))
            pygame.draw.rect(screen, WHITE, (car_x, car_y, car_w, car_h), 3)
            
            # Колёса (круги)
            wheel_size = 40
            wheel_y = car_y + car_h - 15
            pygame.draw.circle(screen, BLACK, (car_x + 30, wheel_y + 20), wheel_size // 2)
            pygame.draw.circle(screen, BLACK, (car_x + car_w - 30, wheel_y + 20), wheel_size // 2)
            pygame.draw.circle(screen, GRAY, (car_x + 30, wheel_y + 20), wheel_size // 3)
            pygame.draw.circle(screen, GRAY, (car_x + car_w - 30, wheel_y + 20), wheel_size // 3)
            
            # Название
            name = self.game.font_medium.render(car.name, True, YELLOW)
            screen.blit(name, (car_x, car_y - 40))
            
            # Характеристики
            stats = [
                f"HP: {int(car.get_total_hp())} ({car.base_hp} base)",
                f"Weight: {int(car.get_total_weight())} kg",
                f"Power/Weight: {car.get_total_hp()/car.get_total_weight():.2f}",
                f"0-100: {car.calculate_performance()}s",
                f"Condition: {int(car.condition * 100)}%",
                f"Value: ${car.get_value()}",
            ]
            
            y = car_y + car_h + 40
            for stat in stats:
                text = self.game.font_small.render(stat, True, WHITE)
                screen.blit(text, (car_x, y))
                y += 30
            
            # Детали
            parts_x = SCREEN_WIDTH - 350
            parts_y = 200
            
            title = self.game.font_medium.render("PARTS:", True, ORANGE)
            screen.blit(title, (parts_x, parts_y))
            
            parts = [
                ("Engine:", car.parts['engine'].name if car.parts['engine'] else "Stock"),
                ("Turbo:", car.parts['turbo'].name if car.parts['turbo'] else "None"),
                ("Tires:", car.parts['tires'].name if car.parts['tires'] else "Stock"),
                ("Trans:", car.parts['transmission'].name if car.parts['transmission'] else "Stock"),
            ]
            
            y = parts_y + 40
            for label, value in parts:
                color = GREEN if value not in ["Stock", "None"] else GRAY
                l = self.game.font_small.render(label, True, WHITE)
                v = self.game.font_small.render(value, True, color)
                screen.blit(l, (parts_x, y))
                screen.blit(v, (parts_x + 80, y))
                y += 30
            
            # Навигация
            if len(self.game.player.garage) > 1:
                nav = f"{self.game.player.selected_car_index + 1}/{len(self.game.player.garage)}"
                text = self.game.font_small.render(nav, True, GRAY)
                screen.blit(text, (SCREEN_WIDTH // 2 - 20, SCREEN_HEIGHT - 160))
                
                hint = self.game.font_small.render("← → arrows", True, GRAY)
                screen.blit(hint, (SCREEN_WIDTH // 2 - 60, SCREEN_HEIGHT - 130))
        
        for button in self.buttons:
            button.draw(screen)
