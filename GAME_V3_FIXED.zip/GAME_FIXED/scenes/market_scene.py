"""scenes/market_scene.py - Рынок машин"""

import pygame
import random
import json
import os
from config.settings import *
from config.game_config import MARKET_REFRESH_COST, MIN_MARKET_CARS, MAX_MARKET_CARS
from core.states import MENU
from ui.button import Button
from models.car import Car

class MarketScene:
    """Рынок с машинами из JSON"""
    
    def __init__(self, game):
        self.game = game
        self.car_database = self.load_cars()
        self.available_cars = []
        self.generate_market()
        
        button_y = SCREEN_HEIGHT - 100
        self.buttons = [
            Button(50, button_y, 150, 50, "BACK", GRAY, game.font_medium),
            Button(220, button_y, 220, 50, f"REFRESH ${MARKET_REFRESH_COST}", BLUE, game.font_medium),
        ]
    
    def load_cars(self):
        """Загрузить базу из JSON"""
        try:
            with open("data/cars.json", 'r', encoding='utf-8') as f:
                data = json.load(f)
                cars = data.get('cars', [])
                print(f"✅ Загружено {len(cars)} машин")
                return cars
        except:
            print("⚠️  cars.json не найден, используем заглушку")
            return [
                {"name": f"Машина #{i}", "hp": 100 + i * 30, "weight": 1000 + i * 100, "price": 500 + i * 300}
                for i in range(1, 16)
            ]
    
    def generate_market(self):
        """Генерация случайных машин"""
        self.available_cars = []
        
        if not self.car_database:
            return
        
        num = random.randint(MIN_MARKET_CARS, min(MAX_MARKET_CARS, len(self.car_database)))
        selected = random.sample(self.car_database, num)
        
        for data in selected:
            condition = round(random.uniform(0.3, 0.9), 2)
            price = int(data.get('price', 1000) * random.uniform(0.8, 1.2))
            
            car_data = data.copy()
            car_data['condition'] = condition
            car_data['price'] = price
            
            car = Car.from_dict(car_data)
            self.available_cars.append(car)
        
        print(f"🛒 Рынок обновлён: {len(self.available_cars)} машин")
    
    def handle_event(self, event):
        for i, button in enumerate(self.buttons):
            if button.handle_event(event):
                if i == 0:
                    self.game.current_state = MENU
                elif i == 1:
                    if self.game.player.money >= MARKET_REFRESH_COST:
                        self.game.player.money -= MARKET_REFRESH_COST
                        self.generate_market()
        
        if event.type == pygame.MOUSEBUTTONDOWN:
            mx, my = event.pos
            
            for i, car in enumerate(self.available_cars):
                y = 150 + i * 120
                buy_rect = pygame.Rect(SCREEN_WIDTH - 220, y + 70, 180, 35)
                
                if buy_rect.collidepoint(mx, my):
                    if self.game.player.buy_car(car):
                        print(f"✅ Куплена: {car.name} за ${car.price}")
                        self.available_cars.remove(car)
                    else:
                        print(f"❌ Недостаточно денег")
    
    def update(self, dt):
        pass
    
    def draw(self, screen):
        title = self.game.font_large.render("MARKET", True, YELLOW)
        screen.blit(title, (50, 30))
        
        subtitle = self.game.font_small.render(f"Машин: {len(self.available_cars)}", True, WHITE)
        screen.blit(subtitle, (50, 90))
        
        for i, car in enumerate(self.available_cars):
            y = 150 + i * 120
            
            # Карточка
            card = pygame.Rect(50, y, SCREEN_WIDTH - 100, 110)
            pygame.draw.rect(screen, DARK_GRAY, card)
            pygame.draw.rect(screen, WHITE, card, 2)
            
            # Превью машины - ЦВЕТНОЙ БЛОК
            preview_x = 70
            preview_y = y + 30
            preview_w = 120
            preview_h = 38
            
            pygame.draw.rect(screen, car.color, (preview_x, preview_y, preview_w, preview_h))
            pygame.draw.rect(screen, WHITE, (preview_x, preview_y, preview_w, preview_h), 2)
            
            # Колёса
            wheel = 12
            wy = preview_y + preview_h - 5
            pygame.draw.circle(screen, BLACK, (preview_x + 15, wy), wheel // 2)
            pygame.draw.circle(screen, BLACK, (preview_x + preview_w - 15, wy), wheel // 2)
            
            # Инфо
            info_x = 210
            info_y = y + 15
            
            name = self.game.font_medium.render(car.name, True, YELLOW)
            screen.blit(name, (info_x, info_y))
            
            stats = f"HP: {car.base_hp} | Weight: {car.base_weight}kg | Condition: {int(car.condition*100)}%"
            stats_text = self.game.font_small.render(stats, True, WHITE)
            screen.blit(stats_text, (info_x, info_y + 35))
            
            perf = f"0-100: {car.calculate_performance()}s | P/W: {car.base_hp/car.base_weight:.2f}"
            perf_text = self.game.font_small.render(perf, True, WHITE)
            screen.blit(perf_text, (info_x, info_y + 60))
            
            # Цена
            price = self.game.font_medium.render(f"${car.price}", True, GREEN)
            screen.blit(price, (info_x, info_y + 85))
            
            # Кнопка BUY
            buy_color = GREEN if self.game.player.money >= car.price else RED
            buy_rect = pygame.Rect(SCREEN_WIDTH - 220, y + 70, 180, 35)
            pygame.draw.rect(screen, buy_color, buy_rect, border_radius=5)
            pygame.draw.rect(screen, WHITE, buy_rect, 2, border_radius=5)
            
            buy_text = self.game.font_medium.render("BUY", True, WHITE)
            buy_text_rect = buy_text.get_rect(center=buy_rect.center)
            screen.blit(buy_text, buy_text_rect)
        
        for button in self.buttons:
            button.draw(screen)
