"""scenes/race_scene.py - Драг-рейсинг"""

import pygame
import random
from config.settings import *
from core.states import GARAGE
from ui.button import Button

class RaceScene:
    """Драг-рейсинг 1/4 мили"""
    
    def __init__(self, game):
        self.game = game
        
        # Состояние гонки
        self.race_state = "COUNTDOWN"  # COUNTDOWN, RACING, FINISHED
        self.countdown = 3.0
        
        # Игрок
        self.player_distance = 0  # метры
        self.player_speed = 0  # км/ч
        self.player_rpm = 1000
        self.player_gear = 1
        self.player_time = 0
        
        # NOS
        self.nos_active = False
        self.nos_remaining = 3.0  # секунды
        
        # Противник (AI)
        self.opponent_distance = 0
        self.opponent_speed = 0
        self.opponent_time = 0
        self.opponent_car = None
        
        # Финиш
        self.finish_distance = 402  # 1/4 мили = 402 метра
        self.winner = None
        self.prize_money = 0
        
        # Физика
        self.wheel_spin = False
        self.perfect_start = False
        
        # Кнопки
        button_y = SCREEN_HEIGHT - 100
        self.buttons = [
            Button(50, button_y, 150, 50, "BACK", GRAY, game.font_medium),
            Button(SCREEN_WIDTH // 2 - 100, button_y, 200, 50, "RESTART", BLUE, game.font_medium),
        ]
        
        # Генерируем противника
        self.generate_opponent()
    
    def generate_opponent(self):
        """Генерация противника на основе машины игрока"""
        player_car = self.game.player.get_selected_car()
        
        if not player_car:
            return
        
        # Клонируем характеристики игрока с вариацией ±10%
        from models.car import Car
        
        variation = random.uniform(0.9, 1.1)
        
        self.opponent_car = Car(
            name=f"Opponent #{random.randint(1, 99)}",
            hp=int(player_car.base_hp * variation),
            weight=int(player_car.base_weight * variation),
            price=0
        )
        
        # Случайный цвет
        self.opponent_car.color = (
            random.randint(50, 255),
            random.randint(50, 255),
            random.randint(50, 255)
        )
        
        # Призовые в зависимости от сложности
        player_value = player_car.get_value()
        self.prize_money = int(player_value * 0.15)  # 15% от стоимости машины
    
    def reset_race(self):
        """Сброс гонки"""
        self.race_state = "COUNTDOWN"
        self.countdown = 3.0
        
        self.player_distance = 0
        self.player_speed = 0
        self.player_rpm = 1000
        self.player_gear = 1
        self.player_time = 0
        
        self.opponent_distance = 0
        self.opponent_speed = 0
        self.opponent_time = 0
        
        self.nos_active = False
        car = self.game.player.get_selected_car()
        if car:
            self.nos_remaining = 3.0 if car.get_nos_boost() > 0 else 0
        
        self.winner = None
        self.wheel_spin = False
        self.perfect_start = False
        
        self.generate_opponent()
    
    def handle_event(self, event):
        """Обработка событий"""
        # Кнопки
        for i, button in enumerate(self.buttons):
            if button.handle_event(event):
                if i == 0:  # BACK
                    self.game.current_state = GARAGE
                elif i == 1:  # RESTART
                    self.reset_race()
        
        if event.type == pygame.KEYDOWN:
            # SPACE - переключение передачи
            if event.key == pygame.K_SPACE:
                if self.race_state == "RACING":
                    self.shift_up()
            
            # N - NOS
            if event.key == pygame.K_n:
                if self.race_state == "RACING" and self.nos_remaining > 0:
                    self.nos_active = True
            
            # ENTER - старт (при отсчёте)
            if event.key == pygame.K_RETURN:
                if self.race_state == "COUNTDOWN":
                    # Проверка идеального старта
                    if 0.1 < self.countdown < 0.3:
                        self.perfect_start = True
                        print("🎯 PERFECT START!")
    
    def shift_up(self):
        """Переключение на высшую передачу"""
        car = self.game.player.get_selected_car()
        if not car:
            return
        
        max_gear = len(car.gear_ratios)
        
        if self.player_gear < max_gear:
            # Проверка оптимального момента переключения
            optimal_rpm_min = 5500
            optimal_rpm_max = 7000
            
            if optimal_rpm_min <= self.player_rpm <= optimal_rpm_max:
                # Идеальное переключение
                self.player_gear += 1
                self.player_rpm = max(2000, self.player_rpm - 2000)
                print(f"✅ Gear {self.player_gear} - Perfect!")
            elif self.player_rpm < optimal_rpm_min:
                # Слишком рано
                self.player_gear += 1
                self.player_rpm = max(1500, self.player_rpm - 1500)
                self.player_speed *= 0.9  # Потеря скорости
                print(f"⚠️ Gear {self.player_gear} - Too early!")
            else:
                # Нормальное переключение
                self.player_gear += 1
                self.player_rpm = max(2000, self.player_rpm - 2500)
                print(f"Gear {self.player_gear}")
    
    def update(self, dt):
        """Обновление физики гонки"""
        car = self.game.player.get_selected_car()
        if not car:
            return
        
        # Отсчёт
        if self.race_state == "COUNTDOWN":
            self.countdown -= dt
            
            if self.countdown <= 0:
                self.race_state = "RACING"
                print("🏁 GO!")
        
        # Гонка
        elif self.race_state == "RACING":
            # Обновление игрока
            self.update_player(dt, car)
            
            # Обновление противника (AI)
            self.update_opponent(dt)
            
            # Проверка финиша
            if self.player_distance >= self.finish_distance:
                self.finish_race("PLAYER")
            elif self.opponent_distance >= self.finish_distance:
                self.finish_race("OPPONENT")
    
    def update_player(self, dt, car):
        """Обновление физики игрока"""
        # Базовые параметры
        hp = car.get_total_hp()
        weight = car.get_total_weight()
        grip = car.get_grip()
        shift_speed = car.get_shift_speed()
        
        # NOS
        if self.nos_active and self.nos_remaining > 0:
            hp += car.get_nos_boost()
            self.nos_remaining -= dt
            
            if self.nos_remaining <= 0:
                self.nos_active = False
                print("💨 NOS закончился!")
        
        # Power to weight
        pwr = hp / weight
        
        # RPM растёт
        rpm_gain = pwr * 100 * dt * shift_speed
        self.player_rpm += rpm_gain
        self.player_rpm = min(8000, self.player_rpm)
        
        # Redline - потеря мощности
        if self.player_rpm > 7500:
            pwr *= 0.5
        
        # Передаточное число
        gear_ratio = car.gear_ratios[self.player_gear - 1]
        
        # Ускорение
        acceleration = (pwr * 50 / gear_ratio) * grip
        
        # Идеальный старт бонус
        if self.perfect_start and self.player_time < 1.0:
            acceleration *= 1.3
        
        # Пробуксовка на старте
        if self.player_speed < 30 and grip < 0.8:
            self.wheel_spin = True
            acceleration *= 0.7
        else:
            self.wheel_spin = False
        
        # Скорость
        self.player_speed += acceleration * dt
        self.player_speed = max(0, self.player_speed)
        
        # Сопротивление воздуха
        drag = 0.01 * (self.player_speed ** 2)
        self.player_speed -= drag * dt
        
        # Дистанция (м)
        self.player_distance += (self.player_speed / 3.6) * dt
        
        # Время
        self.player_time += dt
    
    def update_opponent(self, dt):
        """AI противника"""
        if not self.opponent_car:
            return
        
        # Простой AI - идеальное переключение
        hp = self.opponent_car.get_total_hp()
        weight = self.opponent_car.get_total_weight()
        pwr = hp / weight
        
        # AI переключает передачи автоматически в оптимальный момент
        optimal_speed_per_gear = [0, 60, 100, 140, 180, 220, 260]
        
        for gear in range(1, 7):
            if self.opponent_speed < optimal_speed_per_gear[gear]:
                opponent_gear = gear
                break
        else:
            opponent_gear = 6
        
        # Ускорение AI
        acceleration = pwr * 40 / opponent_gear
        
        self.opponent_speed += acceleration * dt * random.uniform(0.95, 1.05)
        
        # Дистанция
        self.opponent_distance += (self.opponent_speed / 3.6) * dt
        
        # Время
        self.opponent_time += dt
    
    def finish_race(self, winner):
        """Финиш гонки"""
        self.race_state = "FINISHED"
        self.winner = winner
        
        car = self.game.player.get_selected_car()
        
        if winner == "PLAYER":
            # Победа!
            self.game.player.win_race(self.prize_money, xp_reward=100)
            
            if car:
                car.races_won += 1
                car.total_earnings += self.prize_money
                car.wear_parts(0.02)  # Износ после гонки
            
            print(f"🏆 ПОБЕДА! +${self.prize_money}")
        else:
            # Поражение
            self.game.player.lose_race(xp_reward=20)
            
            if car:
                car.races_lost += 1
                car.wear_parts(0.01)
            
            print(f"😞 Поражение...")
    
    def draw(self, screen):
        """Отрисовка"""
        # Заголовок
        title = self.game.font_large.render("DRAG RACE", True, RED)
        screen.blit(title, (SCREEN_WIDTH // 2 - 120, 20))
        
        # Трасса
        self.draw_track(screen)
        
        # Машины
        self.draw_cars(screen)
        
        # HUD
        self.draw_hud(screen)
        
        # Отсчёт
        if self.race_state == "COUNTDOWN":
            self.draw_countdown(screen)
        
        # Результат
        if self.race_state == "FINISHED":
            self.draw_results(screen)
        
        # Кнопки
        for button in self.buttons:
            button.draw(screen)
    
    def draw_track(self, screen):
        """Отрисовать трассу"""
        track_y = SCREEN_HEIGHT // 2
        track_height = 200
        
        # Асфальт
        pygame.draw.rect(screen, DARK_GRAY, (0, track_y - 100, SCREEN_WIDTH, track_height))
        
        # Разметка
        for i in range(0, SCREEN_WIDTH, 80):
            pygame.draw.rect(screen, YELLOW, (i, track_y - 5, 40, 10))
        
        # Стартовая линия
        pygame.draw.rect(screen, WHITE, (50, track_y - 100, 5, track_height))
        
        # Финишная линия
        finish_x = 50 + int((SCREEN_WIDTH - 100) * (self.finish_distance / self.finish_distance))
        pygame.draw.rect(screen, WHITE, (SCREEN_WIDTH - 50, track_y - 100, 5, track_height))
    
    def draw_cars(self, screen):
        """Отрисовать машины"""
        track_y = SCREEN_HEIGHT // 2
        car_width = 120
        car_height = 40
        
        # Позиции на основе дистанции
        max_screen_x = SCREEN_WIDTH - 100
        
        # Игрок
        player_x = 50 + int((max_screen_x - 50) * (self.player_distance / self.finish_distance))
        player_x = min(max_screen_x, player_x)
        player_y = track_y - 80
        
        car = self.game.player.get_selected_car()
        if car:
            # Кузов
            pygame.draw.rect(screen, car.color, (player_x, player_y, car_width, car_height))
            pygame.draw.rect(screen, WHITE, (player_x, player_y, car_width, car_height), 2)
            
            # Колёса
            wheel_size = 20
            pygame.draw.circle(screen, BLACK, (player_x + 20, player_y + car_height), wheel_size // 2)
            pygame.draw.circle(screen, BLACK, (player_x + car_width - 20, player_y + car_height), wheel_size // 2)
            
            # Пробуксовка
            if self.wheel_spin and self.race_state == "RACING":
                for _ in range(5):
                    smoke_x = player_x + random.randint(-10, 10)
                    smoke_y = player_y + car_height + random.randint(0, 15)
                    pygame.draw.circle(screen, GRAY, (smoke_x, smoke_y), random.randint(3, 8))
        
        # Противник
        if self.opponent_car:
            opp_x = 50 + int((max_screen_x - 50) * (self.opponent_distance / self.finish_distance))
            opp_x = min(max_screen_x, opp_x)
            opp_y = track_y + 40
            
            pygame.draw.rect(screen, self.opponent_car.color, (opp_x, opp_y, car_width, car_height))
            pygame.draw.rect(screen, WHITE, (opp_x, opp_y, car_width, car_height), 2)
            
            pygame.draw.circle(screen, BLACK, (opp_x + 20, opp_y + car_height), wheel_size // 2)
            pygame.draw.circle(screen, BLACK, (opp_x + car_width - 20, opp_y + car_height), wheel_size // 2)
    
    def draw_hud(self, screen):
        """HUD с информацией"""
        hud_x = 50
        hud_y = 100
        
        # Скорость
        speed_text = self.game.font_large.render(f"{int(self.player_speed)} km/h", True, GREEN)
        screen.blit(speed_text, (hud_x, hud_y))
        
        # RPM
        rpm_color = RED if self.player_rpm > 7500 else YELLOW if self.player_rpm > 6500 else GREEN
        rpm_text = self.game.font_medium.render(f"RPM: {int(self.player_rpm)}", True, rpm_color)
        screen.blit(rpm_text, (hud_x, hud_y + 60))
        
        # Передача
        gear_text = self.game.font_medium.render(f"GEAR: {self.player_gear}", True, CYAN)
        screen.blit(gear_text, (hud_x, hud_y + 100))
        
        # Дистанция
        dist_text = self.game.font_small.render(f"Distance: {int(self.player_distance)}m / {self.finish_distance}m", True, WHITE)
        screen.blit(dist_text, (hud_x, hud_y + 140))
        
        # NOS
        car = self.game.player.get_selected_car()
        if car and car.get_nos_boost() > 0:
            nos_color = GREEN if self.nos_remaining > 0 else RED
            nos_text = self.game.font_small.render(f"NOS: {self.nos_remaining:.1f}s", True, nos_color)
            screen.blit(nos_text, (hud_x, hud_y + 170))
            
            if self.nos_active:
                active = self.game.font_medium.render("NOS ACTIVE!", True, CYAN)
                screen.blit(active, (hud_x, hud_y + 195))
        
        # Подсказки
        if self.race_state == "RACING":
            hint1 = self.game.font_small.render("SPACE - Shift", True, GRAY)
            hint2 = self.game.font_small.render("N - NOS", True, GRAY)
            screen.blit(hint1, (SCREEN_WIDTH - 200, 100))
            screen.blit(hint2, (SCREEN_WIDTH - 200, 125))
    
    def draw_countdown(self, screen):
        """Отрисовать отсчёт"""
        if self.countdown > 0:
            count = int(self.countdown) + 1
            text = self.game.font_large.render(str(count), True, YELLOW)
            rect = text.get_rect(center=(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2 - 100))
            screen.blit(text, rect)
        else:
            go = self.game.font_large.render("GO!", True, GREEN)
            rect = go.get_rect(center=(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2 - 100))
            screen.blit(go, rect)
        
        # Подсказка
        hint = self.game.font_small.render("Press ENTER for perfect start!", True, CYAN)
        rect = hint.get_rect(center=(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2 - 50))
        screen.blit(hint, rect)
    
    def draw_results(self, screen):
        """Отрисовать результаты"""
        result_y = SCREEN_HEIGHT // 2 - 150
        
        if self.winner == "PLAYER":
            result = self.game.font_large.render("YOU WIN!", True, GREEN)
            prize = self.game.font_medium.render(f"Prize: ${self.prize_money}", True, YELLOW)
        else:
            result = self.game.font_large.render("YOU LOSE!", True, RED)
            prize = self.game.font_medium.render("Better luck next time!", True, GRAY)
        
        result_rect = result.get_rect(center=(SCREEN_WIDTH // 2, result_y))
        screen.blit(result, result_rect)
        
        prize_rect = prize.get_rect(center=(SCREEN_WIDTH // 2, result_y + 60))
        screen.blit(prize, prize_rect)
        
        # Время
        time_text = self.game.font_small.render(f"Your time: {self.player_time:.2f}s", True, WHITE)
        time_rect = time_text.get_rect(center=(SCREEN_WIDTH // 2, result_y + 100))
        screen.blit(time_text, time_rect)
        
        opp_time = self.game.font_small.render(f"Opponent: {self.opponent_time:.2f}s", True, WHITE)
        opp_rect = opp_time.get_rect(center=(SCREEN_WIDTH // 2, result_y + 130))
        screen.blit(opp_time, opp_rect)
