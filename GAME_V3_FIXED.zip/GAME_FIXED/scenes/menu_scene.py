"""scenes/menu_scene.py - Главное меню"""

import pygame
from config.settings import SCREEN_WIDTH, SCREEN_HEIGHT, YELLOW, GREEN, BLUE, RED
from core.states import GARAGE, MARKET, RACE, QUIT
from ui.button import Button

class MenuScene:
    """Главное меню"""
    
    def __init__(self, game):
        self.game = game
        
        # Кнопки
        button_width = 300
        button_height = 80
        start_y = 300
        spacing = 100
        center_x = SCREEN_WIDTH // 2 - button_width // 2
        
        self.buttons = [
            Button(center_x, start_y, button_width, button_height, "GARAGE", GREEN, game.font_large),
            Button(center_x, start_y + spacing, button_width, button_height, "MARKET", BLUE, game.font_large),
            Button(center_x, start_y + spacing * 2, button_width, button_height, "RACE", YELLOW, game.font_large),
            Button(center_x, start_y + spacing * 3, button_width, button_height, "EXIT", RED, game.font_large),
        ]
    
    def handle_event(self, event):
        for i, button in enumerate(self.buttons):
            if button.handle_event(event):
                if i == 0:
                    self.game.current_state = GARAGE
                elif i == 1:
                    self.game.current_state = MARKET
                elif i == 2:
                    self.game.current_state = RACE
                elif i == 3:
                    self.game.current_state = QUIT
                    self.game.running = False
    
    def update(self, dt):
        pass
    
    def draw(self, screen):
        title = self.game.font_large.render("GARAGE TYCOON", True, YELLOW)
        screen.blit(title, (SCREEN_WIDTH // 2 - 200, 150))
        
        for button in self.buttons:
            button.draw(screen)
