"""scenes/tuning_scene.py - Сцена тюнинга машины"""

import pygame
import json
import os
from config.settings import *
from core.states import GARAGE
from ui.button import Button
from models.part import Part

class TuningScene:
    """Тюнинг: установка деталей на машину"""
    
    def __init__(self, game):
        self.game = game
        
        # Загружаем базу деталей
        self.parts_database = self.load_parts_database()
        
        # Выбранная категория
        self.selected_category = 'engine'
        self.categories = ['engine', 'turbo', 'tires', 'transmission', 'suspension', 'exhaust', 'nos']
        self.category_names = {
            'engine': 'ENGINE',
            'turbo': 'TURBO',
            'tires': 'TIRES',
            'transmission': 'TRANSMISSION',
            'suspension': 'SUSPENSION',
            'exhaust': 'EXHAUST',
            'nos': 'NOS'
        }
        
        # Прокрутка списка деталей
        self.scroll_offset = 0
        
        # Кнопки
        button_y = SCREEN_HEIGHT - 100
        self.buttons = [
            Button(50, button_y, 150, 50, "BACK", GRAY, game.font_medium),
            Button(220, button_y, 200, 50, "INVENTORY", ORANGE, game.font_medium),
        ]
        
        # Кнопки категорий
        self.create_category_buttons()
    
    def load_parts_database(self):
        """Загрузить базу деталей из JSON"""
        try:
            with open("data/parts.json", 'r', encoding='utf-8') as f:
                data = json.load(f)
                parts_data = data.get('parts', {})
                
                # Конвертируем в объекты Part
                parts_dict = {}
                for category, parts_list in parts_data.items():
                    parts_dict[category] = []
                    for part_data in parts_list:
                        part_data['type'] = category
                        part = Part.from_dict(part_data)
                        parts_dict[category].append(part)
                
                print(f"✅ Загружено {sum(len(v) for v in parts_dict.values())} деталей")
                return parts_dict
        except Exception as e:
            print(f"❌ Ошибка загрузки parts.json: {e}")
            return {}
    
    def create_category_buttons(self):
        """Создать кнопки категорий"""
        self.category_buttons = []
        start_x = 50
        y = 100
        width = 150
        height = 40
        spacing = 10
        
        colors = [RED, ORANGE, YELLOW, GREEN, CYAN, BLUE, PURPLE]
        
        for i, category in enumerate(self.categories):
            button = Button(
                start_x,
                y + i * (height + spacing),
                width,
                height,
                self.category_names[category],
                colors[i % len(colors)],
                self.game.font_small
            )
            self.category_buttons.append(button)
    
    def handle_event(self, event):
        """Обработка событий"""
        # Основные кнопки
        for i, button in enumerate(self.buttons):
            if button.handle_event(event):
                if i == 0:  # BACK
                    self.game.current_state = GARAGE
                elif i == 1:  # INVENTORY
                    # TODO: Открыть инвентарь
                    pass
        
        # Кнопки категорий
        for i, button in enumerate(self.category_buttons):
            if button.handle_event(event):
                self.selected_category = self.categories[i]
                self.scroll_offset = 0
        
        # Колёсико мыши для прокрутки
        if event.type == pygame.MOUSEWHEEL:
            self.scroll_offset -= event.y * 30
            self.scroll_offset = max(0, self.scroll_offset)
        
        # Клики на детали
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            self.handle_part_click(event.pos)
    
    def handle_part_click(self, pos):
        """Обработка клика на деталь"""
        mx, my = pos
        
        car = self.game.player.get_selected_car()
        if not car:
            return
        
        # Область списка деталей
        list_x = 220
        list_y = 100
        list_w = 550
        item_h = 80
        
        # Получаем детали выбранной категории
        parts = self.parts_database.get(self.selected_category, [])
        
        for i, part in enumerate(parts):
            y = list_y + i * item_h - self.scroll_offset
            
            # Пропускаем если за пределами видимости
            if y < list_y - item_h or y > SCREEN_HEIGHT - 150:
                continue
            
            # Прямоугольник детали
            part_rect = pygame.Rect(list_x, y, list_w, item_h - 5)
            
            if part_rect.collidepoint(mx, my):
                # Проверяем уровень
                if self.game.player.level < part.level_required:
                    print(f"❌ Нужен уровень {part.level_required}!")
                    return
                
                # Покупаем и устанавливаем
                if self.game.player.buy_part(part):
                    # Создаём новый экземпляр детали (чтобы можно было купить много раз)
                    new_part = Part.from_dict({
                        'id': part.part_id,
                        'name': part.name,
                        'type': part.part_type,
                        'hp_bonus': part.hp_bonus,
                        'weight_bonus': part.weight_bonus,
                        'price': part.price,
                        'level_required': part.level_required,
                        'description': part.description,
                        'grip': part.grip,
                        'shift_speed': part.shift_speed,
                        'handling': part.handling,
                        'nos_boost': part.nos_boost
                    })
                    
                    # Установить сразу
                    success, old_part = car.install_part(new_part)
                    
                    if success:
                        print(f"✅ Куплено и установлено: {part.name}")
                        
                        # Старую деталь продаём автоматически
                        if old_part and old_part.price > 0:
                            refund = old_part.get_sell_price()
                            self.game.player.add_money(refund)
                            print(f"💰 Возврат за старую: ${refund}")
                else:
                    print(f"❌ Недостаточно денег! Нужно: ${part.price}")
    
    def update(self, dt):
        """Обновление"""
        pass
    
    def draw(self, screen):
        """Отрисовка"""
        # Заголовок
        title = self.game.font_large.render("TUNING", True, CYAN)
        screen.blit(title, (50, 30))
        
        car = self.game.player.get_selected_car()
        
        if not car:
            text = self.game.font_medium.render("Нет машины!", True, WHITE)
            screen.blit(text, (400, 300))
        else:
            # Кнопки категорий (слева)
            for button in self.category_buttons:
                button.draw(screen)
            
            # Подсветка выбранной категории
            selected_index = self.categories.index(self.selected_category)
            highlight_rect = self.category_buttons[selected_index].rect
            pygame.draw.rect(screen, WHITE, highlight_rect, 4)
            
            # Список деталей (центр)
            self.draw_parts_list(screen, car)
            
            # Характеристики машины (справа)
            self.draw_car_stats(screen, car)
        
        # Кнопки
        for button in self.buttons:
            button.draw(screen)
    
    def draw_parts_list(self, screen, car):
        """Отрисовать список деталей"""
        list_x = 220
        list_y = 100
        list_w = 550
        list_h = SCREEN_HEIGHT - 250
        
        # Фон списка
        pygame.draw.rect(screen, DARK_GRAY, (list_x, list_y, list_w, list_h))
        pygame.draw.rect(screen, WHITE, (list_x, list_y, list_w, list_h), 2)
        
        # Заголовок категории
        cat_title = self.game.font_medium.render(
            self.category_names[self.selected_category],
            True,
            YELLOW
        )
        screen.blit(cat_title, (list_x + 10, list_y - 40))
        
        # Получаем детали
        parts = self.parts_database.get(self.selected_category, [])
        
        if not parts:
            text = self.game.font_small.render("Нет деталей", True, GRAY)
            screen.blit(text, (list_x + 200, list_y + 100))
            return
        
        # Текущая установленная деталь
        current_part = car.parts.get(self.selected_category)
        
        # Рисуем детали
        item_h = 80
        
        for i, part in enumerate(parts):
            y = list_y + 10 + i * item_h - self.scroll_offset
            
            # Пропускаем если за пределами
            if y < list_y - item_h or y > list_y + list_h:
                continue
            
            # Фон детали
            part_rect = pygame.Rect(list_x + 5, y, list_w - 10, item_h - 5)
            
            # Цвет фона
            if current_part and current_part.part_id == part.part_id:
                bg_color = (0, 100, 0)  # Зелёный если установлена
            elif self.game.player.level < part.level_required:
                bg_color = (80, 0, 0)  # Красный если уровень низкий
            else:
                bg_color = (40, 40, 40)
            
            pygame.draw.rect(screen, bg_color, part_rect)
            pygame.draw.rect(screen, WHITE, part_rect, 1)
            
            # Название
            name_color = WHITE if self.game.player.level >= part.level_required else GRAY
            name = self.game.font_small.render(part.name, True, name_color)
            screen.blit(name, (part_rect.x + 10, part_rect.y + 5))
            
            # Характеристики
            stats_y = part_rect.y + 30
            
            if part.hp_bonus != 0:
                hp_text = self.game.font_small.render(f"+{part.hp_bonus}HP", True, GREEN)
                screen.blit(hp_text, (part_rect.x + 10, stats_y))
            
            if part.weight_bonus != 0:
                color = RED if part.weight_bonus > 0 else GREEN
                w_text = self.game.font_small.render(f"{part.weight_bonus:+}kg", True, color)
                screen.blit(w_text, (part_rect.x + 100, stats_y))
            
            # Цена
            price_color = GREEN if self.game.player.money >= part.price else RED
            price = self.game.font_medium.render(f"${part.price}", True, price_color)
            screen.blit(price, (part_rect.x + list_w - 150, part_rect.y + 25))
            
            # Требуемый уровень
            if part.level_required > 0:
                lvl_color = GREEN if self.game.player.level >= part.level_required else RED
                lvl = self.game.font_small.render(f"Lv.{part.level_required}", True, lvl_color)
                screen.blit(lvl, (part_rect.x + 200, stats_y))
    
    def draw_car_stats(self, screen, car):
        """Отрисовать характеристики машины"""
        stats_x = SCREEN_WIDTH - 350
        stats_y = 100
        
        # Заголовок
        title = self.game.font_medium.render("ХАРАКТЕРИСТИКИ:", True, YELLOW)
        screen.blit(title, (stats_x, stats_y))
        
        # Название машины
        name = self.game.font_small.render(car.name, True, WHITE)
        screen.blit(name, (stats_x, stats_y + 40))
        
        # Статистика
        stats = car.get_stats_dict()
        
        stat_lines = [
            f"HP: {stats['hp']}",
            f"Weight: {stats['weight']}kg",
            f"P/W: {stats['power_to_weight']}",
            f"0-100: {stats['0-100']}s",
            f"1/4 mile: {stats['quarter_mile']}s",
            f"Grip: {stats['grip']:.2f}",
            f"Shift: {stats['shift_speed']:.1f}x",
            f"Handling: {stats['handling']:.2f}",
            "",
            f"Condition: {stats['condition']}%",
            f"Value: ${stats['value']}"
        ]
        
        y = stats_y + 80
        for line in stat_lines:
            text = self.game.font_small.render(line, True, WHITE)
            screen.blit(text, (stats_x, y))
            y += 25
        
        # Установленные детали
        y += 20
        parts_title = self.game.font_small.render("INSTALLED:", True, ORANGE)
        screen.blit(parts_title, (stats_x, y))
        y += 30
        
        for part_type in self.categories:
            part = car.parts.get(part_type)
            if part and part.price > 0:  # Пропускаем stock детали
                color = GREEN
                label = f"• {part.name[:15]}"
            else:
                color = GRAY
                label = f"• Stock"
            
            text = self.game.font_small.render(label, True, color)
            screen.blit(text, (stats_x, y))
            y += 22
